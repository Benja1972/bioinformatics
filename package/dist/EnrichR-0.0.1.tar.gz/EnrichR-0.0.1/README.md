# EnrichR 

This is a simple package for enrichment analysis with clustering.
[Github-flavored Markdown](https://github.com/Benja1972/bioinformatics/)